---
name: Obsidian Flux
colors:
  surface: '#121315'
  surface-dim: '#121315'
  surface-bright: '#38393b'
  surface-container-lowest: '#0d0e10'
  surface-container-low: '#1b1c1e'
  surface-container: '#1f2022'
  surface-container-high: '#292a2c'
  surface-container-highest: '#343537'
  on-surface: '#e3e2e4'
  on-surface-variant: '#c4c7c8'
  inverse-surface: '#e3e2e4'
  inverse-on-surface: '#303032'
  outline: '#8e9192'
  outline-variant: '#444748'
  surface-tint: '#c6c6c6'
  primary: '#ffffff'
  on-primary: '#2f3131'
  primary-container: '#e2e2e2'
  on-primary-container: '#636465'
  inverse-primary: '#5d5f5f'
  secondary: '#c7c6c6'
  on-secondary: '#2f3131'
  secondary-container: '#484949'
  on-secondary-container: '#b8b8b8'
  tertiary: '#ffffff'
  on-tertiary: '#342f2e'
  tertiary-container: '#eae0dd'
  on-tertiary-container: '#6a6361'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c6'
  on-primary-fixed: '#1a1c1c'
  on-primary-fixed-variant: '#454747'
  secondary-fixed: '#e3e2e2'
  secondary-fixed-dim: '#c7c6c6'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#464747'
  tertiary-fixed: '#eae0dd'
  tertiary-fixed-dim: '#cec5c2'
  on-tertiary-fixed: '#1f1b19'
  on-tertiary-fixed-variant: '#4b4544'
  background: '#121315'
  on-background: '#e3e2e4'
  surface-variant: '#343537'
  surface-toolbar: '#202124'
  surface-address: '#26272A'
  surface-card: '#292A2D'
  border-subtle: rgba(255, 255, 255, 0.08)
  accent-blue: '#1A73E8'
typography:
  clock-display:
    fontFamily: Inter
    fontSize: 72px
    fontWeight: '300'
    lineHeight: 80px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-ui:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-margin: 48px
  gutter: 24px
  toolbar-height: 48px
  address-bar-width: 640px
---

## Brand & Style

The design system is a manifestation of **High-End Industrial Minimalism**. It is engineered for a premium desktop browsing experience where the interface recedes to prioritize content and focus. The aesthetic is "technical-luxe"—drawing inspiration from high-end matte hardware and professional creative suites.

The style leverages a **Modern Minimalist** movement with a heavy emphasis on "Monotone Layering." By using a strictly controlled palette of near-blacks and cool grays, the system creates depth through tonal shifts rather than shadows. The emotional response should be one of calm, precision, and unyielding reliability. Negative space is used as a functional tool to reduce cognitive load, ensuring that every interactive element feels intentional and isolated from visual noise.

## Colors

The palette is anchored in a deep, matte aesthetic. The primary color is not a "brand hue" but rather the light-gray text that cuts through the dark backgrounds. 

- **Layering Logic:** We use an inverted elevation model where the "closest" elements to the user (like the Address Bar) are lighter in tone than the background.
- **Accents:** Use the `accent-blue` sparingly, only for active states or critical focus indicators. 
- **Transitions:** All color shifts on hover must utilize a 200ms ease-out transition to maintain the "soft" premium feel specified in the requirements.

## Typography

This design system utilizes **Inter** exclusively to achieve a systematic, utilitarian appearance. The typographic hierarchy is driven by weight and spacing rather than size dramaticism. 

- **The Clock:** For "New Tab" experiences, use the `clock-display` token with weight 300 to evoke a sense of precision.
- **UI Labels:** Small labels should use weight 500 or 600 with slight letter-spacing to maintain legibility against dark backgrounds. 
- **Rendering:** Ensure `antialiased` font rendering is forced to preserve the sharpness of thin weights on high-resolution displays.

## Layout & Spacing

The layout follows a **Fixed-Width Content** philosophy for the central browsing canvas, while the browser chrome (toolbar/tabs) remains fluid. 

- **The 4px Rhythm:** All spacing should be multiples of 4px. Use 48px margins for the primary dashboard to create a luxurious sense of space.
- **Quick Link Grid:** Use a centered grid for quick links. Icons are 72x72px, arranged with a 24px gutter.
- **Alignment:** Center-align the address bar and search components to create a balanced vertical axis.

## Elevation & Depth

Depth is achieved through **Tonal Layering** and **Subtle Outlines** rather than traditional shadows.

- **The "Surface Stack":** 
  - Level 0: `#1B1C1E` (Main Background)
  - Level 1: `#202124` (Toolbar/Sidebars)
  - Level 2: `#292A2D` (Cards/Modals)
  - Level 3: `#26272A` (Interactive Inputs like Address Bar)
- **Borders:** Every floating element (tabs, cards, inputs) must have a `1px` solid border of `rgba(255, 255, 255, 0.08)`. This creates a "micro-rim" light effect that defines edges without adding visual weight.
- **No Shadows:** Do not use `box-shadow` properties unless specifically required for accessibility on overlapping third-party content.

## Shapes

The design system balances technical geometry with soft, organic touchpoints. 

- **Search/Address Bars:** These must always be **Full Pill** shaped (radius 999px) to distinguish them from structural UI elements.
- **Quick Links:** These use a custom radius of `18px` on a `72px` square, creating a "Squircle-adjacent" appearance.
- **Tabs:** Use a top-only radius of `12px` to seamlessly integrate with the toolbar line.

## Components

### Buttons & Inputs
- **Search Bar:** Capsule-shaped, background `#26272A`, text `Primary`. Placeholder text should use `Secondary Text` color.
- **Quick Links:** `72x72px` squares, background `#292A2D`. Icons should be monochromatic `#E5E5E5`.

### Navigation
- **Tabs:** Rounded top corners (12px). Active tab should match the toolbar color (`#202124`), while inactive tabs are slightly more transparent or darker.
- **Address Bar:** Centered, pill-shaped, subtle border. On focus, the border opacity increases to `rgba(255, 255, 255, 0.2)`.

### Cards & Surfaces
- **Content Cards:** Background `#292A2D`. No shadow. Use `16px` internal padding. 
- **Hover States:** All interactive elements should brighten by 4-6% on hover. Avoid sudden color changes; use a smooth fade.

### Lists
- **Dropdowns/Context Menus:** Use a background blur effect (`backdrop-filter: blur(10px)`) combined with `#292A2D` at 90% opacity to create a "glass-minimalist" feel for temporary overlays.